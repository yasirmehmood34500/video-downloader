<div class="container mt-5 mb-5">
    <div class="row mt-3 mb-3">
        <div class="col-lg-4 col-md-6 col-sm-12 mt-2 mb-2 ">
            <div class="banner">
                <div class="icon text-center">
                    <i style="font-size:36px;color:#06159c" class="fa fa-circle-o-notch"></i>
                </div>
                <h5>Unlimited Conversions</h5>
                <p>We offers unlimited conversions of youtube videos to mp3 and mp4.</p>

            </div>


        </div>
        <div class="col-lg-4 col-md-6 col-sm-12 mt-2 mb-2">

            <div class="banner">
                <div class="icon text-center">
                    <i style="font-size:36px;color:#06159c" class="fa fa-download"></i>
                </div>
                <h5>Unlimited Conversions</h5>
                <p>We offers unlimited conversions of youtube videos to mp3 and mp4.</p>

            </div>

        </div>
        <div class="col-lg-4 col-md-6 col-sm-12 mt-2 mb-2 ">


            <div class="banner">
                <div class="icon text-center">
                    <i style="font-size:36px;color:#06159c" class="fa fa-user"></i>
                </div>
                <h5>Unlimited Conversions</h5>
                <p>We offers unlimited conversions of youtube videos to mp3 and mp4.</p>

            </div>

        </div>
    </div>




    <!-- now for seacond row -->



    <div class="row mt-4 mb-4">
        <div class="col-lg-4 col-md-6 col-sm-12 mt-2 mb-2 ">
            <div class="banner">
                <div class="icon text-center">
                    <i style="font-size:36px;color:#06159c" class="fa fa-bolt "></i>
                </div>

                <h5>Unlimited Conversions</h5>
                <p>We offers unlimited conversions of youtube videos to mp3 and mp4.</p>

            </div>


        </div>
        <div class="col-lg-4 col-md-6 col-sm-12 mt-2 mb-2">

            <div class="banner">
                <div class="icon text-center">
                    <i style="font-size:36px;color:#06159c" class="fa fa-check text-center"></i>
                </div>
                <h5>Unlimited Conversions</h5>
                <p>We offers unlimited conversions of youtube videos to mp3 and mp4.</p>

            </div>

        </div>
        <div class="col-lg-4 col-md-6 col-sm-12 mt-2 mb-2">


            <div class="banner">
                <div class="icon text-center ">
                    <i style="font-size:36px;color:#06159c" class="fa fa-mobile"></i>
                </div>
                <h5>Unlimited Conversions</h5>
                <p>We offers unlimited conversions of youtube videos to mp3 and mp4.</p>

            </div>

        </div>
    </div>


</div>