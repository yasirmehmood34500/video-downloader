
 <div  class="container w-100 " >
<div class="row">
    <div class="col-md-10 col-lg-10 col-sm-12 mx-5 mr-5 ">
<nav class="navbar fixed-top  navbar-expand-lg  ">
  <div class="container-fluid ">
    <a class="navbar-brand" href="#">Logo</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span  class="navbar-toggler-icon"><i class="fa fa-bars"></i></span> 
      
    </button>
    <div class="collapse navbar-collapse " id="navbarSupportedContent">
      <ul class="navbar-nav  mb-2 ms-auto mb-lg-0 justify-content-end ">
        <li class="nav-item ">
          <a class="nav-link " aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="click_down" href="#resultBlock">Doc</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Pages</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Forum</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Blogs</a>
        </li>
        
       
      </ul>
     
    </div>
  </div>
</nav>
</div>
</div>
</div>